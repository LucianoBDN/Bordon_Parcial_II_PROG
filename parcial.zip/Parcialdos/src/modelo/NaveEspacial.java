/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;

public class NaveEspacial implements CSVSerializable, Comparable<NaveEspacial>, Serializable {

    private static final Long serielVersionUID = 1L;
    private int id;
    private String nombre;
    private TipoNave tipo;
    private int CAPACIDAD_MAX;

    public NaveEspacial(int id, String nombre, TipoNave tipo, int CAPACIDAD_MAX) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.CAPACIDAD_MAX = CAPACIDAD_MAX;
    }

    @Override
    public String toString() {
        return "NaveEspacial: " + "id: " + id + ", nombre: " + nombre + ", tipo: " + tipo + ", CAPACIDAD_MAX: " + CAPACIDAD_MAX;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoNave getTipo() {
        return tipo;
    }

    public int getCAPACIDAD_MAX() {
        return CAPACIDAD_MAX;
    }
    
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + tipo.toString() + "," + CAPACIDAD_MAX;
    }

    @Override
    public int compareTo(NaveEspacial n) {
        return Integer.compare(id, n.id);
    }

public static NaveEspacial fromCSV(String naveCSV) {
        NaveEspacial aux = null;
        String[] values = naveCSV.split(",");
        if (values.length == 4) {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            int CapacidadTripulacion = Integer.parseInt(values[2]);
            TipoNave tipo = TipoNave.valueOf(values[3]);
            aux = new NaveEspacial(id, nombre,tipo, CapacidadTripulacion );
        }
        return aux;
    }

}
