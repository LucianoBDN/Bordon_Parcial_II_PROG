package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T> implements Iterable<T> {

    List<T> naves = new ArrayList<>();

    //Pregunta si lo que recibe es Null, si es tira una excepcion y si no agrega el item a la lista
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se pueden guardas Null");
        }
        naves.add(item);
    }

    //llama a la funcion checkRango para validar el indice, si es valido(si existe) lo remueve
    public void eliminar(int indice) {
        checkRango(indice);
        naves.remove(indice);
    }

    //si el rango no existe dentro de la lista lanza una excepcion, y si existe el programa sigue
    private void checkRango(int rango) {
        if (rango < 0 || rango >= naves.size()) {
            throw new ArrayIndexOutOfBoundsException("Fuera de rango");
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T nave : naves) {
            accion.accept(nave);
        }
    }

    @Override
    public Iterator<T> iterator() {
        if (!naves.isEmpty() && naves.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<T>(naves)).iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        ArrayList<T> aux = new ArrayList<>(naves);
        aux.sort(comparador);
        return aux.iterator();
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T nave : naves) {
            if (criterio.test(nave)) {
                aux.add(nave);
            }
        }
        return aux;
    }

    public void ordenar() {
        ordenar((Comparator<? super T>) Comparator.naturalOrder());
    }

    public void ordenar(Comparator<? super T> comparador) {
        naves.sort(comparador);
    }

    public void guardarEnArchivo(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(naves);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) {

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            naves = (List<T>) entrada.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

    }

   public void guardarEnCSV(String path) {
        File archivo = new File(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            bw.write("id,titulo,autor,categoria\n");
            for (T l : naves) {
                if (l instanceof CSVSerializable csv) {
                    bw.write(csv.toCSV() + "\n");
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void cargarDesdeCSV(String path, Function<String, T> transformador) {
        File archivo = new File(path);
        
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                br.readLine();
                while ((linea = br.readLine()) != null) {
                    naves.add(transformador.apply(linea));

                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
        }
       
    }    
 
    public void limpiar(){
    naves.clear();
}
    
}
