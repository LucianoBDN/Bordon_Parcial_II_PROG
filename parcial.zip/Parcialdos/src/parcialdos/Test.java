/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcialdos;

import static config.PathConstants.PATH_CSV;
import static config.PathConstants.PATH_SERIAL;
import java.util.List;
import modelo.Inventario;
import modelo.NaveEspacial;
import modelo.TipoNave;

/**
 *
 * @author lucia
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear un inventario de naves espaciales 
        Inventario<NaveEspacial> inventarioNaves = new Inventario<>();
        inventarioNaves.agregar(new NaveEspacial(2, "Millennium Falcon", TipoNave.TRANSPORTE, 10));
        inventarioNaves.agregar(new NaveEspacial(4, "X-Wing", TipoNave.MILITAR, 11));
        inventarioNaves.agregar(new NaveEspacial(3, "TIE Fighter", TipoNave.MILITAR, 130));
        inventarioNaves.agregar(new NaveEspacial(5, "Discovery One", TipoNave.CIENTIFICA, 14));
        inventarioNaves.agregar(new NaveEspacial(1, "USS Enterprise", TipoNave.CIENTIFICA, 15));

        // Mostrar todas las naves en el inventario 
        System.out.println("Inventario de naves espaciales:");
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        separador();

        // Filtrar naves por categoría MILITAR 
        System.out.println("\nNaves de la categoría MILITAR:");
        inventarioNaves.filtrar((NaveEspacial n) -> n.getTipo().equals(TipoNave.MILITAR)).forEach(nave -> System.out.println(nave));

        separador();

        /*Filtrar naves cuyo nombre contiene "Falcon" 
        System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
        inventarioNaves.filtrar((NaveEspacial n) -> n.getNombre().compareTo("Falcon")).forEach(nave -> System.out.println(nave));
        separador();*/

        // Ordenar naves de manera natural (por id)
        System.out.println("\nNaves ordenadas de manera natural (id):");
        inventarioNaves.ordenar();
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        separador();
        // Ordenar naves por nombre utilizando un Comparator
        System.out.println("\nNaves ordenadas por nombre:");
        inventarioNaves.ordenar((n1, n2) -> n1.getNombre().compareTo(n2.getNombre()));
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        separador();

        inventarioNaves.guardarEnArchivo("src/data/naves.dat");
        System.out.println("Guardando en archivo...");

        separador();

        // Cargar el inventario desde el archivo binario
        Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo("src/data/naves.dat");
        System.out.println("\nNaves cargadas desde archivo binario:");
        inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        separador();
        
        // Guardar el inventario en un archivo CSV
        inventarioNaves.guardarEnCSV("src/data/naves.csv");
        System.out.println("Guardando en archivo...");
        inventarioCargado.limpiar();
       // Cargar el inventario desde el archivo CSV
        inventarioCargado.cargarDesdeCSV("src/data/naves.csv", linea -> NaveEspacial.fromCSV("src/data/naves.csv"));
        System.out.println("\nNaves cargadas desde archivo CSV:");
        inventarioNaves.paraCadaElemento(nave -> System.out.println(nave));

        separador();
        System.out.println("\nNaves Transformadas a Militar: ");
       
        

        
    }

    public static void separador() {
        System.out.println("---------------------------------------------------------");
    }

}
