/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

public class PathConstants {

    public static final String PATH_FILES = "src/data/";
    public static final String PATH_CSV = PATH_FILES + "naves.csv";
    public static final String PATH_SERIAL = PATH_FILES + "naves.dat";
}
